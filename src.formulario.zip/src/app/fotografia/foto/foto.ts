export interface Img {
    id: number,
    descr: string,
    titulo: string,
    n: number
}